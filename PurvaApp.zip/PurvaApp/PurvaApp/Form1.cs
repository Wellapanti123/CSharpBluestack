﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PurvaApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void StartDownload(string _url, string fullPathWhereToSave)
        {
            try
            {
                if (!Directory.Exists(Path.GetDirectoryName(fullPathWhereToSave)))
                    System.IO.Directory.CreateDirectory(Path.GetDirectoryName(fullPathWhereToSave));

                if (File.Exists(fullPathWhereToSave))
                    File.Delete(fullPathWhereToSave);

                using (WebClient client = new WebClient())
                {
                    var ur = new Uri(_url);
                    // client.Credentials = new NetworkCredential("username", "password");
                    client.DownloadProgressChanged += WebClientDownloadProgressChanged;
                    client.DownloadFileCompleted += WebClientDownloadCompleted;
                    client.DownloadFileAsync(ur, fullPathWhereToSave);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Please enter a valid URL for download");
            }
        }
        private void WebClientDownloadCompleted(object sender, AsyncCompletedEventArgs args)
        {
            var fullPathWhereToSave = textBox2.Text;
            if (File.Exists(fullPathWhereToSave))
            {
                FileInfo fi = new FileInfo(fullPathWhereToSave);
                if (!(fi.Length > 0))
                    File.Delete(fullPathWhereToSave);
            }
            if (File.Exists(fullPathWhereToSave))
            {
                MessageBox.Show("Download completed");
            }
            else
            {
                MessageBox.Show("File cannot be downloaded from this URL");
            }
            progressBar1.Visible = false;
        }

        private void WebClientDownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            progressBar1.Value = e.ProgressPercentage;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox1.Text))
            {
                progressBar1.Visible = true;
                StartDownload(textBox1.Text, textBox2.Text);
            }
            else
            {
                MessageBox.Show("Enter a URL for download");
            }
        }
    }
}
